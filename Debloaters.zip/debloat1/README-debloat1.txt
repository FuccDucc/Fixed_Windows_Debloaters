Powershell as Admin >

Set-ExecutionPolicy Unrestricted -Scope CurrentUser
Set-ExecutionPolicy Unrestricted -Force

>> write: 
1) cd [path of SCRIPTS folder]
2) input all .ps1 debloater scripts one by one, to your liking (use prefix ./ to bypass trust blocking)

Example inputs after eachother, this is actually my preference of all routines to run:
./block-telemetry.ps1
./disable-scheduled-tasks.ps1
./disable-services.ps1
./disable-services-v2.ps1
./disable-windows-defender.ps1
./fix-privacy-settings.ps1
./optimize-user-interface.ps1
./optimize-windows-update.ps1
./ssd-tune.ps1
./remove-onedrive-long.ps1
./remove-default-apps-long.ps1
./unfuckery_long.ps1

Then you merge "lower-ram-usage.reg" to registry (double click) and run each .bat file, "Run as Administrator" in rightclick, or from cmd as Admin in the cd directory.
I mean these .bat files:

Disable_Insecure_Features.bat
Disable_Windows_Defender.bat
Windows_Debloater.bat
HardenOS.bat


For a final touch, go to the folder "Debloaters\Extra Procedures" and use "Services debloat.txt" as well.
After that, consider all extra files in that same folder, it's good for your privacy, performance and PC. Don't forget "Various Tweaks for Privacy and Performance.txt"