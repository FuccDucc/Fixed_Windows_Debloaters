Powershell as Admin >

Set-ExecutionPolicy Unrestricted -Scope CurrentUser
Set-ExecutionPolicy Unrestricted -Force

>> write: 
1) cd [path where script is located]
2) ./Windows10Debloater.ps1

